# _.CloudsApi

All URIs are relative to *http://localhost:8080/api/v1/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cancelCloudById**](CloudsApi.md#cancelCloudById) | **DELETE** /clouds/{cloud_id} | Метод отмены заказа в облаке по ID
[**createCloud**](CloudsApi.md#createCloud) | **GET** /clouds | Метод получения списка ресурса на облаке
[**createCloud_0**](CloudsApi.md#createCloud_0) | **POST** /clouds | Создавать заказ в облаке
[**getCloudById**](CloudsApi.md#getCloudById) | **GET** /clouds/{cloud_id} | Метод получения заказа в облаке по ID

<a name="cancelCloudById"></a>
# **cancelCloudById**
> cancelCloudById(cloudId)

Метод отмены заказа в облаке по ID

### Example
```javascript
import {_} from '___';

let apiInstance = new _.CloudsApi();
let cloudId = "cloudId_example"; // String | Идентификатор заказа в облаке

apiInstance.cancelCloudById(cloudId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cloudId** | **String**| Идентификатор заказа в облаке | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json

<a name="createCloud"></a>
# **createCloud**
> Clouds createCloud()

Метод получения списка ресурса на облаке

### Example
```javascript
import {_} from '___';

let apiInstance = new _.CloudsApi();
apiInstance.createCloud((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Clouds**](Clouds.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, adplication/json

<a name="createCloud_0"></a>
# **createCloud_0**
> Clouds createCloud_0(opts)

Создавать заказ в облаке

### Example
```javascript
import {_} from '___';

let apiInstance = new _.CloudsApi();
let opts = { 
  'body': new _.Error() // Error | 
};
apiInstance.createCloud_0(opts, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Error**](Error.md)|  | [optional] 

### Return type

[**Clouds**](Clouds.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: adplication/json
 - **Accept**: adplication/json

<a name="getCloudById"></a>
# **getCloudById**
> getCloudById(cloudId)

Метод получения заказа в облаке по ID

### Example
```javascript
import {_} from '___';

let apiInstance = new _.CloudsApi();
let cloudId = "cloudId_example"; // String | Идентификатор заказа в облаке

apiInstance.getCloudById(cloudId, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cloudId** | **String**| Идентификатор заказа в облаке | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: adplication/json

