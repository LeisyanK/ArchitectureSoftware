# _.Cloud

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cloudId** | **String** |  | [optional] 
**idClient** | **String** |  | 
**OS** | **String** | Операционная система сервера | 
**RAM** | **String** | Объем оперативной памяти | 
**CPU** | **String** | Количество ядер процессора | 

<a name="OSEnum"></a>
## Enum: OSEnum

* `windows` (value: `"Windows"`)
* `linux` (value: `"Linux"`)

